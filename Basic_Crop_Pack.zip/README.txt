Item_Display、Item_Frame、Tirpwire are 3 different crop modes. You only need to install one of them to make the crop work. 
All you need to do is put the corresponding plugin configuration in the correct folder.
By default, there are two crop configurations for CustomCrops. If you are using ItemsAdder, delete files ending with "_oraxen.yml", and vice versa.
If you have problems with installation, open a thread on #Support channel.

Default assets contributors: Cha_Shao、TopOrigin
Translators: Masaki (spanish)、Unreal (simplified_chinese)、Deliable (turkish)